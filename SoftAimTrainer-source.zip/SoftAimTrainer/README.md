# Soft Aim Trainer (Android source)

A standalone Android touch-aim practice prototype for practicing precision and consistency. It does **not** read, modify, inject into, or overlay Free Fire, and does not automate game input.

## Build
1. Install Android Studio (current stable) and Android SDK 35.
2. Open this folder as a project.
3. Let Gradle sync, then select **Build > Build APK(s)**.
4. The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.

## Use
Tap the small red head target. The larger amber ring gives a near-hit score. The target relocates after each attempt. Accuracy is displayed at the bottom. Use RESET to restart.

Tested only as source generation here; an APK has not been built or device-tested in this environment.
