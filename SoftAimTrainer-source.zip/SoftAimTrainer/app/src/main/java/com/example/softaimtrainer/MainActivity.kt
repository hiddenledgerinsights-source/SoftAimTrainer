package com.example.softaimtrainer

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import kotlin.math.hypot
import kotlin.random.Random

/** Standalone touch-aim trainer. It does not connect to or modify any game. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(TrainerView())
    }
}

private class TrainerView : View {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var headX = 0f
    private var headY = 0f
    private var bodyX = 0f
    private var bodyY = 0f
    private var targetR = 34f
    private var score = 0
    private var shots = 0
    private var headHits = 0
    private var showHint = true
    private var lastToastAt = 0L

    constructor(context: android.content.Context) : super(context) {
        isFocusable = true
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        c.drawColor(Color.rgb(17, 24, 39))
        p.color = Color.WHITE
        p.textSize = 42f
        c.drawText("SOFT AIM TRAINER", 32f, 66f, p)
        p.textSize = 27f
        c.drawText("Score: $score     Shots: $shots     Head hits: $headHits", 32f, 110f, p)
        p.textSize = 22f
        c.drawText("Tap the small head target. Drag gently to practice control.", 32f, 150f, p)

        // Simple target dummy, with a distinct head circle.
        p.color = Color.rgb(80, 95, 115)
        c.drawRoundRect(bodyX - 62f, bodyY + 25f, bodyX + 62f, bodyY + 190f, 28f, 28f, p)
        p.color = Color.rgb(248, 190, 100)
        c.drawCircle(headX, headY, targetR * 1.65f, p)
        p.color = Color.rgb(230, 75, 75)
        c.drawCircle(headX, headY, targetR, p)
        p.color = Color.WHITE
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        c.drawCircle(headX, headY, targetR * 1.65f, p)
        p.style = Paint.Style.FILL

        p.textSize = 25f
        p.color = Color.LTGRAY
        c.drawText("Accuracy: ${if (shots == 0) 0 else (headHits * 100 / shots)}%", 32f, height - 95f, p)
        c.drawText("Tap RESET to start another round", 32f, height - 55f, p)
        p.color = Color.rgb(55, 125, 220)
        c.drawRoundRect(width - 190f, height - 145f, width - 32f, height - 32f, 22f, 22f, p)
        p.color = Color.WHITE
        p.textSize = 27f
        c.drawText("RESET", width - 158f, height - 77f, p)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        moveTarget()
    }

    private fun moveTarget() {
        if (width < 1 || height < 1) return
        headX = Random.nextInt(75, (width - 75).coerceAtLeast(76)).toFloat()
        headY = Random.nextInt(230, (height - 270).coerceAtLeast(231)).toFloat()
        bodyX = headX
        bodyY = headY
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            val x = event.x
            val y = event.y
            if (x > width - 210f && y > height - 165f) {
                score = 0; shots = 0; headHits = 0
                moveTarget()
                Toast.makeText(context, "Round reset", Toast.LENGTH_SHORT).show()
                return true
            }
            shots++
            val d = hypot(x - headX, y - headY)
            if (d <= targetR) {
                headHits++
                score += 100
                Toast.makeText(context, "HEAD HIT +100", Toast.LENGTH_SHORT).show()
            } else if (d <= targetR * 1.65f) {
                score += 25
                Toast.makeText(context, "Near hit +25", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Miss — keep it controlled", Toast.LENGTH_SHORT).show()
            }
            moveTarget()
            return true
        }
        return true
    }
}
